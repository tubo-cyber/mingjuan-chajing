//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D2ZdZ37v.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/columns",
			"/intro",
			"/topics",
			"/view",
			"/book/$bookId",
			"/column/$slug",
			"/topic/$topicId",
			"/read/$bookId/$kind/$chap"
		],
		preloads: ["/assets/index-JsujYOGK.js", "/assets/prefs-CrW5XWuI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-JsujYOGK.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CzpAPehf.js", "/assets/app-shell-bXF8n5Ln.js"]
	},
	"/columns": {
		filePath: "/workspace/src/routes/columns.tsx",
		children: void 0,
		preloads: ["/assets/columns-DEmTdlF9.js", "/assets/app-shell-bXF8n5Ln.js"]
	},
	"/intro": {
		filePath: "/workspace/src/routes/intro.tsx",
		children: void 0,
		preloads: ["/assets/intro-BrbB73sv.js", "/assets/app-shell-bXF8n5Ln.js"]
	},
	"/topics": {
		filePath: "/workspace/src/routes/topics.tsx",
		children: void 0,
		preloads: ["/assets/topics-BKg1B3HC.js", "/assets/app-shell-bXF8n5Ln.js"]
	},
	"/view": {
		filePath: "/workspace/src/routes/view.tsx",
		children: void 0,
		preloads: [
			"/assets/view-CV1QwCtX.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js",
			"/assets/reader-view-mN1jL3lv.js"
		]
	},
	"/book/$bookId": {
		filePath: "/workspace/src/routes/book.$bookId.tsx",
		children: void 0,
		preloads: [
			"/assets/book._bookId-DO1TfkJh.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js"
		]
	},
	"/column/$slug": {
		filePath: "/workspace/src/routes/column.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/column._slug-Ct2UJCm-.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js"
		]
	},
	"/topic/$topicId": {
		filePath: "/workspace/src/routes/topic.$topicId.tsx",
		children: void 0,
		preloads: [
			"/assets/topic._topicId-DFzbTtlx.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js"
		]
	},
	"/read/$bookId/$kind/$chap": {
		filePath: "/workspace/src/routes/read.$bookId.$kind.$chap.tsx",
		children: void 0,
		preloads: [
			"/assets/read._bookId._kind._chap-CpUqQX5M.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js",
			"/assets/reader-view-mN1jL3lv.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
